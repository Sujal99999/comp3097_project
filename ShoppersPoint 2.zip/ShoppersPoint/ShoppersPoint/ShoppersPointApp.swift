import SwiftUI

// MARK: - Shopping Item Model
struct ShoppingItem: Identifiable, Codable, Equatable {
    var id: UUID
    var name: String
    var category: String
    var price: Double

    init(id: UUID = UUID(), name: String, category: String, price: Double) {
        self.id = id
        self.name = name
        self.category = category
        self.price = price
    }
}

// MARK: - Shopping List Model
struct ShoppingList: Identifiable, Codable {
    var id: UUID
    var name: String
    var items: [ShoppingItem]

    init(id: UUID = UUID(), name: String, items: [ShoppingItem] = []) {
        self.id = id
        self.name = name
        self.items = items
    }
}

// MARK: - ViewModel
class ShoppingViewModel: ObservableObject {
    @Published var shoppingLists: [ShoppingList] = []
    @Published var selectedListID: UUID? {
        didSet {
            if let selectedID = selectedListID {
                // Save the selected list ID when it changes
                UserDefaults.standard.set(selectedID.uuidString, forKey: "selectedListID")
            } else {
                UserDefaults.standard.removeObject(forKey: "selectedListID")
            }
        }
    }
    @Published var taxRate: Double = 0.01  // Default 1% tax

    init() {
        loadLists()
        taxRate = UserDefaults.standard.double(forKey: "taxRate") == 0 ? 0.01 : UserDefaults.standard.double(forKey: "taxRate")
        
        // Load the previously selected list ID
        if let savedIDString = UserDefaults.standard.string(forKey: "selectedListID"),
           let savedID = UUID(uuidString: savedIDString) {
            // Verify the ID exists in our loaded lists
            if shoppingLists.contains(where: { $0.id == savedID }) {
                selectedListID = savedID
            }
        }
        
        // If no list is selected and we have lists, select the first one
        if selectedListID == nil && !shoppingLists.isEmpty {
            selectedListID = shoppingLists[0].id
        }
    }

    var selectedList: ShoppingList? {
        shoppingLists.first(where: { $0.id == selectedListID })
    }

    // Create a new shopping list
    func addList(name: String) {
        let newList = ShoppingList(name: name)
        shoppingLists.append(newList)
        selectedListID = newList.id
        saveLists()
    }

    // Add item to the selected shopping list
    func addItem(name: String, category: String, price: Double) {
        guard let index = shoppingLists.firstIndex(where: { $0.id == selectedListID }) else { return }
        shoppingLists[index].items.append(ShoppingItem(name: name, category: category, price: price))
        saveLists()
    }

    // Delete a shopping list
    func deleteList(at offsets: IndexSet) {
        // Check if we're deleting the selected list
        let deletingSelected = offsets.contains(where: { shoppingLists[$0].id == selectedListID })
        
        shoppingLists.remove(atOffsets: offsets)
        
        // If we deleted the selected list, select another one if available
        if deletingSelected {
            selectedListID = shoppingLists.first?.id
        }
        
        saveLists()
    }

    // Delete an item from the selected list
    func deleteItem(at offsets: IndexSet) {
        guard let index = shoppingLists.firstIndex(where: { $0.id == selectedListID }) else { return }
        shoppingLists[index].items.remove(atOffsets: offsets)
        saveLists()
    }

    // Calculate total price with tax
    func calculateTotal() -> Double {
        guard let selectedList = selectedList else { return 0 }
        return selectedList.items.reduce(0) { $0 + $1.price * (1 + taxRate) }
    }

    // Save and Load Data
    private func saveLists() {
        if let encoded = try? JSONEncoder().encode(shoppingLists) {
            UserDefaults.standard.set(encoded, forKey: "shoppingLists")
        }
    }

    private func loadLists() {
        if let savedData = UserDefaults.standard.data(forKey: "shoppingLists"),
           let decoded = try? JSONDecoder().decode([ShoppingList].self, from: savedData) {
            shoppingLists = decoded
        }
    }
}

// MARK: - Splash Screen View
struct SplashScreenView: View {
    @State private var isActive = false
    @State private var size = 0.8
    @State private var opacity = 0.5
    
    var body: some View {
        if isActive {
            ShoppingListView()
        } else {
            VStack {
                VStack {
                    Image(systemName: "cart.fill")
                        .font(.system(size: 80))
                        .foregroundColor(.blue)
                        .padding()
                    
                    Text("Shoppers Point")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.primary)
                    
                    Text("Built by Sujal Aditya & Leela")
                        .font(.headline)
                        .foregroundColor(.secondary)
                        .padding(.top, 10)
                }
                .scaleEffect(size)
                .opacity(opacity)
                .onAppear {
                    withAnimation(.easeIn(duration: 1.2)) {
                        self.size = 1.0
                        self.opacity = 1.0
                    }
                }
            }
            .onAppear {
                DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
                    withAnimation {
                        self.isActive = true
                    }
                }
            }
        }
    }
}

// MARK: - Shopping List View
struct ShoppingListView: View {
    @StateObject private var viewModel = ShoppingViewModel()
    @State private var showAddListView = false
    @State private var showAddItemView = false

    var body: some View {
        NavigationView {
            VStack {
                List {
                    Section(header: Text("Shopping Lists")) {
                        ForEach(viewModel.shoppingLists) { list in
                            Button(action: { viewModel.selectedListID = list.id }) {
                                HStack {
                                    Text(list.name)
                                    Spacer()
                                    if viewModel.selectedListID == list.id {
                                        Image(systemName: "checkmark.circle.fill")
                                            .foregroundColor(.blue)
                                    }
                                }
                            }
                        }
                        .onDelete(perform: viewModel.deleteList)
                    }

                    Section(header: Text("Items in \(viewModel.selectedList?.name ?? "List")")) {
                        ForEach(viewModel.selectedList?.items ?? []) { item in
                            HStack {
                                VStack(alignment: .leading) {
                                    Text(item.name)
                                        .font(.headline)
                                    Text(item.category)
                                        .font(.subheadline)
                                        .foregroundColor(.secondary)
                                }
                                Spacer()
                                Text(String(format: "$%.2f", item.price))
                                    .bold()
                                    .foregroundColor(.green)
                            }
                        }
                        .onDelete(perform: viewModel.deleteItem)
                    }
                }
                .listStyle(GroupedListStyle())

                Text("Total (incl. \(Int(viewModel.taxRate * 100))% tax): $\(viewModel.calculateTotal(), specifier: "%.2f")")
                    .font(.title2)
                    .bold()
                    .foregroundColor(.blue)
                    .padding()

                HStack {
                    Button(action: { showAddListView = true }) {
                        Label("New List", systemImage: "folder.badge.plus")
                            .padding()
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .cornerRadius(10)
                    }
                    .sheet(isPresented: $showAddListView) {
                        AddListView(viewModel: viewModel)
                    }

                    Button(action: { showAddItemView = true }) {
                        Label("Add Item", systemImage: "plus.circle.fill")
                            .padding()
                            .background(Color.green)
                            .foregroundColor(.white)
                            .cornerRadius(10)
                    }
                    .sheet(isPresented: $showAddItemView) {
                        AddItemView(viewModel: viewModel)
                    }
                    .disabled(viewModel.selectedListID == nil)
                }
            }
            .navigationTitle("Shopping Lists 🛍️")
            .padding()
        }
    }
}

// MARK: - Add List View
struct AddListView: View {
    @Environment(\.presentationMode) var presentationMode
    @ObservedObject var viewModel: ShoppingViewModel
    @State private var listName: String = ""

    var body: some View {
        NavigationView {
            Form {
                TextField("List Name", text: $listName)
            }
            .navigationTitle("New Shopping List")
            .navigationBarItems(
                leading: Button("Cancel") {
                    presentationMode.wrappedValue.dismiss()
                },
                trailing: Button("Save") {
                    if !listName.isEmpty {
                        viewModel.addList(name: listName)
                        presentationMode.wrappedValue.dismiss()
                    }
                }
            )
        }
    }
}

// MARK: - Add Item View
struct AddItemView: View {
    @Environment(\.presentationMode) var presentationMode
    @ObservedObject var viewModel: ShoppingViewModel
    @State private var name: String = ""
    @State private var category: String = "Food"
    @State private var price: String = ""

    let categories = ["Food", "Medication", "Cleaning", "Other"]

    var body: some View {
        NavigationView {
            Form {
                TextField("Item Name", text: $name)
                TextField("Price", text: $price)
                    .keyboardType(.decimalPad)
                Picker("Category", selection: $category) {
                    ForEach(categories, id: \.self) {
                        Text($0)
                    }
                }
            }
            .navigationTitle("Add Item ➕")
            .navigationBarItems(
                leading: Button("Cancel") {
                    presentationMode.wrappedValue.dismiss()
                },
                trailing: Button("Save") {
                    if let priceValue = Double(price), !name.isEmpty {
                        viewModel.addItem(name: name, category: category, price: priceValue)
                        presentationMode.wrappedValue.dismiss()
                    }
                }
            )
        }
    }
}

@main
struct ShoppersPointApp: App {
    var body: some Scene {
        WindowGroup {
            SplashScreenView()
        }
    }
}
