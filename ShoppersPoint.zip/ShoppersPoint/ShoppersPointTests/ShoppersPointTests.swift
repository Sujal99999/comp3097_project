//
//  ShoppersPointTests.swift
//  ShoppersPointTests
//
//  Created by Aastha Saini on 01/03/25.
//

import Testing
@testable import ShoppersPoint

struct ShoppersPointTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
